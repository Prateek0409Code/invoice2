const newInvoice = document.getElementById('newInvoice');
const invoiceTable = document.getElementById('invoiceTable');
const newProductButton = document.getElementById('newProductButton');
const generateInvoiceBtn = document.getElementById('generateInvoiceBtn');
const invoiceDetails = document.getElementById('invoiceDetails');
const grandTotal = document.getElementById('grandTotal');
let srNo = 1;
let totalAmount = 0;
const items = [];


function alreadyInCart(product) {
  return items.some(item => item.product === product);
}

newProductButton.addEventListener('click', function() {
  const product = document.getElementById('product').value;
  const rate = parseFloat(document.getElementById('rate').value);
  const quantity = parseInt(document.getElementById('quantity').value);

  if (!product || isNaN(rate) || isNaN(quantity) || quantity <= 0) {
    alert('Please fill in all fields with valid values.');
    return;
  }

    if (alreadyInCart(product)) {
    alert('This product is already added.');
    return;
  }

  const total = rate * quantity;

  const newRow = `<tr>
    <td>${srNo}</td>
    <td>${product}</td>
    <td>${rate.toFixed(2)}</td>
    <td>${quantity}</td>
    <td>${total.toFixed(2)}</td>
    <td><button class="deleteBtn">Delete Product</button></td>
  </tr>`;
  
  invoiceTable.querySelector('tbody').insertAdjacentHTML('beforeend', newRow);
  
  totalAmount += total;
  grandTotal.textContent = totalAmount.toFixed(2);
  items.push({ product, rate, quantity: quantity });
  
  srNo++;
});

invoiceTable.addEventListener('click', function(event) {
  if (event.target.classList.contains('deleteBtn')) {
    const row = event.target.parentNode.parentNode;
    const totalCell = row.querySelector('td:nth-child(5)');
    const total = parseFloat(totalCell.textContent);
    
    totalAmount -= total;
    grandTotal.textContent = totalAmount.toFixed(2);
    
    row.remove();
    adjustSrNumbers();
  }
});

function adjustSrNumbers() {
  const rows = invoiceTable.querySelectorAll('tbody tr');
  srNo = 1;
  rows.forEach((row, index) => {
    row.querySelector('td:first-child').textContent = srNo++;
  });
}

generateInvoiceBtn.addEventListener('click', function() {
  const name = document.getElementById('name').value;
  const mobile = document.getElementById('mobile').value;
  const date = document.getElementById('date').value;
 // const date = dateInp.value;


  if (!name || !mobile || !date) {
    alert('Please fill in all customer details.');
    return;
  }

  const currentDate = new Date();
  const selectedDate = new Date(date);

  if (selectedDate > currentDate) {
    alert('Please select a date that is not in the future.');
    return;
  }
    if (!isValidMobileNumber(mobile)) {
    alert('Mobile number should be 10 digits.');
    return;
  }

  if (items.length === 0) {
    alert('Please add products to the invoice.');
    return;
  }

  // Rest of your code for generating the invoice
});

function isValidMobileNumber(mobile) {
  const mobileRegex = /^\d{10}$/; // Regular expression to match 10 digits
  return mobileRegex.test(mobile);
}


    function adjustSrNumbers() {
      const rows = invoiceTable.querySelectorAll('tbody tr');
      srNo = 1;
      rows.forEach((row, index) => {
        row.querySelector('td:first-child').textContent = srNo++;
      });
    }

    generateInvoiceBtn.addEventListener('click', function() {
            if (event.keyCode == 36) {
                button.click();
            }
      const name = document.getElementById('name').value;
      const mobile = document.getElementById('mobile').value;
      const date = document.getElementById('date').value;
      const invoiceNumber = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
      const distinctProducts = Array.from(new Set([...document.querySelectorAll('#invoiceTable tbody td:nth-child(2)')].map(td => td.textContent)));
      
      const invoiceDetailsHTML = `
        <h2>Invoice Details</h2>
    <table>
      <tr>
        <th>Product</th>
        <th>Quantity</th>
        <th>Rate</th>
        <th>Total</th>
      </tr>
      ${items.map(item => `
        <tr>
          <td>${item.product}</td>
          <td>${item.quantity}</td>
          <td>${item.rate.toFixed(2)}</td>
          <td>${(item.quantity * item.rate).toFixed(2)}</td>
        </tr>
      `).join('')}
    </table>
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Mobile:</strong> ${mobile}</p>
    <p><strong>Date of Purchase:</strong> ${date}</p>
    <p><strong>Invoice Number:</strong> ${invoiceNumber}</p>
    <p><strong>Number of Products Ordered:</strong> ${items.length}</p>
    <p><strong>Grand Total:</strong> ${totalAmount.toFixed(2)}</p>
  `;
      
      invoiceDetails.innerHTML = invoiceDetailsHTML;
    });